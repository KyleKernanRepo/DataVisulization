let randArr = [0,0,0,0,0];
let sum = 0;
let avg = 0;


(function IFFE(){
  const canvas = document.querySelector("canvas");
  const ctx = canvas.getContext("2d"); 
  const btn = document.querySelector("#btn").addEventListener("click",function(e){
        
    //check for form validation before running function below
    let formData = Array.from(document.querySelectorAll("input"));
    let formValid = formData[0].checkValidity() && formData[1].checkValidity();
    if(formValid){
      e.preventDefault();
      processForm(formData);
      

    }


    createChart();
});

function processForm(data){
  console.log("FORM IS VALID");
  let fromInputData = data.map(e => e.value)
  fromInputData.forEach(e=>{
    console.log(e);
  })  
}
  

  function createChart(){
    console.log("Demo");
    //setup variables
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.strokeStyle = "#000000";  //red line
    ctx.beginPath();
    ctx.lineWidth = 2;     //set width of line
    ctx.moveTo(0,250);     //start pin here
    ctx.lineTo(500,250);   //move pin to here
    ctx.stroke(); 
   ctx.beginPath();       //start a new line
    ctx.strokeStyle = "#000000";  //red line
    ctx.lineWidth = 2;
    ctx.moveTo(250,0);
    ctx.lineTo(250,500);
    ctx.stroke();
    ctx.closePath();//render the line
    
  
  
  
    let posx = 255;
    let userCount = 1;
  
  for (let i = 0; i < 5; i++){
     ctx.beginPath();
     ctx.fillRect(posx,250-randArr[i],40, randArr[i]);
     ctx.stroke();
     ctx.textBaseline = 'ideographic';
     ctx.font = "14px Arial";
     ctx.fillText(randArr[i], posx + 12,250 - randArr[i]);
     ctx.textBaseline = 'hanging';
     ctx.fillText('User: ' + userCount , posx, 255);
     posx +=50;
     sum +=randArr[i];
     randArr[i] = 0;
     userCount++;
     
  
  }
    avg = sum / randArr.length;
    sum = 0;
  document.getElementById("average").innerHTML = "Average: " + avg;
   console.log(randArr);
   console.log(avg);
  
  }

})();






function redraw(){

  // clear the canvas

  const ctx = canvas.getContext("2d");
  ctx.clearRect(0,0,canvas.width,canvas.height);

  // redraw one or more things based on their javascript objects
  ctx.strokeStyle = "#FF0000";  //red line
  ctx.beginPath();
  ctx.lineWidth = 2;     //set width of line
  ctx.moveTo(0,250);     //start pin here
  ctx.lineTo(500,250);   //move pin to here
  ctx.stroke(); 
 ctx.beginPath();       //start a new line
  ctx.strokeStyle = "#FF0000";  //green line
  ctx.moveTo(250,0);
  ctx.lineTo(250,500);
  ctx.stroke();
  ctx.closePath();
}






function finalVal() {
let count = 0;
let min = parseInt(document.getElementById("Min").value);
let max = parseInt(document.getElementById("Max").value);
 //onsole.log(min);
 //console.log(max);

for (let i = 0; i < 5; i++){
  
  if (min !=null && max != null && min >= 10 && min < 100 && max > min && max <= 100) {
  let finalVal = Math.floor(Math.random() * (max - min + 1) ) + min;
    count++;
    
    randArr[i] = finalVal;
    //console.log(finalVal);
    console.log(randArr);
    document.getElementById("random").innerHTML = "Your Numbers: " + randArr;
}else{
alert("Enter min and max value and max value must be greater than min");
  break;
}
}

}

